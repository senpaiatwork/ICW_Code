#include "mcc_generated_files/system.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/mcc.h"

#define Blink_SetDigitalOutput() (_TRISA4 = 0)
#define Blink_SetDigitalInput()  (_TRISA4 = 1)
#define Blink_GetValue()         _RA4
#define Blink_Toggle()           (_LATA4 ^= 1)
#define Blink_SetHigh()          (_LATA4 = 1)
#define Blink_SetLow()           (_LATA4 = 0)

#define FCY 200000UL // Replace with your actual instruction cycle frequency
#define DELAY_2S ((unsigned long)(2*FCY))

void delay_2s(void) {
    for (unsigned long i = 0; i < DELAY_2S; i++);
}

int main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    Blink_SetDigitalOutput(); // Set RA4 as output

    while (1)
    {
        Blink_SetHigh(); // Turn on the LED
        delay_2s();
        Blink_SetLow(); // Turn off the LED
        delay_2s();
    }
    return 1; 
}
